const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  LUCI
──────────────────
        『 *VIP USER* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*AÍ SIM PAE, VOCÊ É UM MEMBRO VIP😎✋`
}
exports.cekvip = cekvip
